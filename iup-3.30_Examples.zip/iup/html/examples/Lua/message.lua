-- IupMessage Example in IupLua 
-- Shows a dialog with the message: �Click the button�. 

require( "iuplua" )

iup.Message ("IupMessage", "Press the button")