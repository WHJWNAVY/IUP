Examples created by Steve Donovan for the
"A Basic Guide to using IupLua"
included in the IUP documentation.
