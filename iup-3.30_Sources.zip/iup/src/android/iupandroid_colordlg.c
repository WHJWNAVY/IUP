/** \file
 * \brief IupColorDlg pre-defined dialog
 *
 * See Copyright Notice in "iup.h"
 */

#include <stdio.h>

#include "iup.h"

#include "iup_object.h"
#include "iup_attrib.h"
#include "iup_str.h"

void iupdrvColorDlgInitClass(Iclass* ic)
{
//  ic->DlgPopup = macColorDlgPopup;
}
