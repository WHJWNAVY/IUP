/** \file
 * \brief MAC Focus
 *
 * See Copyright Notice in "iup.h"
 */


#include <stdio.h>

#include "iup.h"

#include "iup_object.h"
#include "iup_focus.h"
#include "iup_attrib.h"
#include "iup_drv.h"
#include "iup_assert.h" 
#include "iup_drv.h" 

#include "iupandroid_drv.h"


void iupdrvSetFocus(Ihandle *ih)
{               
	
}

void iupmacFocusInOutEvent(Ihandle *ih)
{
}

