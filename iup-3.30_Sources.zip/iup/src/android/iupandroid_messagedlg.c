/** \file
 * \brief MAC IupMessageDlg pre-defined dialog
 *
 * See Copyright Notice in "iup.h"
 */

#include "iup.h"

#include "iup_object.h"
#include "iup_attrib.h"
#include "iup_str.h"
#include "iup_dialog.h"       
#include "iup_strmessage.h"

#include "iupandroid_drv.h"



void iupdrvMessageDlgInitClass(Iclass* ic)
{
//  ic->DlgPopup = macMessageDlgPopup;
}
