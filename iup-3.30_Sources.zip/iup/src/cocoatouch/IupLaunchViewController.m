//
//  IupLaunchViewController.m
//  iup
//
//  Created by Eric Wing on 12/22/16.
//  Copyright © 2016 Tecgraf, PUC-Rio, Brazil. All rights reserved.
//

#import "IupLaunchViewController.h"
#include "iupcocoatouch_drv.h"

@interface IupLaunchViewController ()

@end

@implementation IupLaunchViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
