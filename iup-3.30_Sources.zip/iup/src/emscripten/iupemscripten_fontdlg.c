/** \file
 * \brief IupFontDlg pre-defined dialog
 *
 * See Copyright Notice in "iup.h"
 */


#include <string.h>
#include <memory.h>

#include "iup.h"

#include "iup_object.h"
#include "iup_attrib.h"
#include "iup_str.h"
#include "iup_dialog.h"

#include "iupemscripten_drv.h"


void iupdrvFontDlgInitClass(Iclass* ic)
{
//  ic->DlgPopup = macFontDlgPopup;
}
